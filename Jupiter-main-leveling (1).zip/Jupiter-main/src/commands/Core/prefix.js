import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { createEmbed } from '../../utils/embeds.js';
import { logger } from '../../utils/logger.js';
import { TitanBotError, ErrorTypes } from '../../utils/errorHandler.js';
import { getCommandPrefix } from '../../config/bot.js';
import { getGuildConfig, setGuildConfig } from '../../services/config/guildConfig.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

const MAX_PREFIX_LENGTH = 10;

export default {
  data: new SlashCommandBuilder()
    .setName('prefix')
    .setDescription('Show or change the text-command prefix for this server')
    .addStringOption((option) =>
      option
        .setName('new_prefix')
        .setDescription('New prefix (1-10 characters, no spaces) or "reset". Leave empty to just view it.')
        .setMaxLength(MAX_PREFIX_LENGTH)
        .setRequired(false),
    )
    .setDMPermission(false),
  category: 'Core',

  async execute(interaction, config, client) {
    await InteractionHelper.safeDefer(interaction);

    const guildConfig = await getGuildConfig(client, interaction.guildId);
    const current = guildConfig.prefix || getCommandPrefix();
    const requested = interaction.options.getString('new_prefix')?.trim();

    if (!requested) {
      await InteractionHelper.safeEditReply(interaction, {
        embeds: [
          createEmbed({
            title: '🔤 Command Prefix',
            description:
              `The prefix on this server is \`${current}\`\n\n` +
              `Try \`${current}rank\`, \`${current}leaderboard\` or \`${current}help\`.\n` +
              `Slash commands (\`/rank\`) always work too.\n\n` +
              `Admins can change it with \`${current}prefix <new prefix>\`.`,
            color: 'info',
          }),
        ],
      });
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      throw new TitanBotError(
        'Prefix change without permission',
        ErrorTypes.PERMISSION,
        'You need the **Manage Server** permission to change the prefix.',
      );
    }

    const next = requested.toLowerCase() === 'reset' ? getCommandPrefix() : requested;

    if (next.length > MAX_PREFIX_LENGTH || /\s/.test(next)) {
      throw new TitanBotError(
        `Invalid prefix "${next}"`,
        ErrorTypes.VALIDATION,
        `The prefix must be 1-${MAX_PREFIX_LENGTH} characters with no spaces.`,
      );
    }

    guildConfig.prefix = next;
    await setGuildConfig(client, interaction.guildId, guildConfig);
    logger.info(`Prefix for guild ${interaction.guildId} changed ${current} -> ${next} by ${interaction.user.id}`);

    await InteractionHelper.safeEditReply(interaction, {
      embeds: [
        createEmbed({
          title: '✅ Prefix Updated',
          description: `The prefix is now \`${next}\` (was \`${current}\`).\nExample: \`${next}rank\``,
          color: 'success',
        }),
      ],
    });
  },
};
