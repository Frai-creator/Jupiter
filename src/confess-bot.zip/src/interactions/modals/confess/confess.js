import { IDS, submitConfession, submitReply } from '../../../services/confessService.js';

export default [
  {
    name: IDS.submit,
    execute: (interaction) => submitConfession(interaction),
  },
  {
    name: IDS.replySubmit,
    execute: (interaction, client, args) => submitReply(interaction, args),
  },
];
